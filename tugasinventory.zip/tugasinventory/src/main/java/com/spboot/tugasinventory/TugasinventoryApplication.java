package com.spboot.tugasinventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TugasinventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(TugasinventoryApplication.class, args);
	}

}
